import React from "react";

export default function App() {
  return (
    <div className="loading-container">
      <h2> loading... </h2>
    </div>
  );
}
